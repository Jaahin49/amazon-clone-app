**Live Website Link:  https://clone-ad9dc.web.app/**
[N.B: The live link doesn't connect with the Cloud Firestore because of not having a Blaze account in firebase [ I don't have credit card :( ]. So you may not process the order. But everything works fine in the localhostt]

✅ **The Technology I've used here:**   
    1️⃣ React [ Functional Component + Context API + Hook + React Route]  
    2️⃣ Firebase (Authentication + Cloud Firestore + Deployment)   
    3️⃣ Payment Gateway (Stripe)  
    4️⃣ ES6 (map,reduce,arrow function, let/const, splice) + Material Ui + HTML + CSS   
    5️⃣ Dependency: react-currency-format

✅**Features:**  
Amazon-clone website with FULL E-Commerce Functionality 👇  
    1️⃣ Accounts and Login Page 👨‍👨‍👧‍👦  
    2️⃣ Products Page 📦  
    3️⃣ Cart and Checkout Page  🛒  
    4️⃣ Real Payments 💳  
    5️⃣ Order History Page (Real Time Database)📖  
